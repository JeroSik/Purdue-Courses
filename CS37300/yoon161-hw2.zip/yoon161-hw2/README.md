.data and .label files must be in same directory
