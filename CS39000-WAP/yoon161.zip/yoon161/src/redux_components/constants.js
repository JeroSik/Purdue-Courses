/**
 * TODO: Create an exportable const value.
 * Example:
 * {
 *      ADD_VALUE: "ADD_VALUE"
 * }
 */

export const HistoryRedux = {
    HISTORY_VALUE: "HISTORY_VALUE",
};
