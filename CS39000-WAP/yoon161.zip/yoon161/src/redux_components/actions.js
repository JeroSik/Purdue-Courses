import { HistoryRedux } from "./constants";

export const saveHistory = newHist => ({
  /**
   * TODO: implement saveHistory method which will
   * return a JSON object with values "type" and "newHist".
   * Import the exportable constant from "constants.js" and set that as the "type".
   */
  type: HistoryRedux,
  payload: {
    newHist
  }
});
